<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CountObservations Model
 *
 * @property \App\Model\Table\SessionTable|\Cake\ORM\Association\BelongsToMany $Session
 *
 * @method \App\Model\Entity\CountObservation get($primaryKey, $options = [])
 * @method \App\Model\Entity\CountObservation newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\CountObservation[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\CountObservation|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CountObservation patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\CountObservation[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\CountObservation findOrCreate($search, callable $callback = null, $options = [])
 */
class CountObservationsTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('count_observations');

        $this->belongsToMany('Session', [
            'foreignKey' => 'count_observation_id',
            'targetForeignKey' => 'session_id',
            'joinTable' => 'count_observations_session'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->requirePresence('Number', 'create')
            ->notEmpty('Number');

        return $validator;
    }
}
