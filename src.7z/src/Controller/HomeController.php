<?php
/**
 * Created by PhpStorm.
 * User: foers
 * Date: 11-12-17
 * Time: 12:41
 */

namespace App\Controller;

use App\Controller\AppController;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Cake\Http\Client;

class HomeController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function index() {

        $sessions = null;
        $http = new Client();
        $response = $http->get("http://192.168.128.13:8081/NataRest/api/sessions", [
            'headers' => [
                'api-key' => '24321d8c-b1b3-45bc-9d21-038dfc33b34c'
            ]
        ]);
        if($response->getStatusCode() >= 200 && $response->getStatusCode() <= 299)
            $sessions = $response->body();

        $this->set('sessions', $sessions);
        $this->viewBuilder()->setLayout('base');

    }

    public function isAuthorized($user) {
        return true;
    }
}