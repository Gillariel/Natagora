<?php
/**
 * Created by PhpStorm.
 * User: foers
 * Date: 11-12-17
 * Time: 13:59
 */

namespace App\Controller;

use App\Controller\AppController;
use App\Model\Entity\User;
use Cake\Event\Event;
use Cake\ORM\TableRegistry;
use Cake\Datasource\ConnectionManager;
use Cake\Http\Client;

class LoginController extends AppController
{
    public function initialize()
    {
        parent::initialize();
    }

    public function index() {
        var_dump($_POST);

        if ($this->request->is('post')) {
            $this->Auth->identify();
            $this->redirect('/home');
            /*$_SESSION['username'] = $_POST['username'];
            $_SESSION['password'] = $_POST['password'];
            $this->request_login($_POST['username'], $_POST['password']);
            $user = $this->Auth->identify();
            if ($user) {
                $this->Auth->setUser($user);
                $_SESSION['username'] = $user['username'];
                //$_SESSION['role'] = $user['role'];
                return $this->redirect('/home');
            }
            $this->Flash->error(__('Invalid username or password, please try again'));*/
        }
        /*if(isset($this->Flash))
            $this->Flash->render();
        */
        $this->viewBuilder()->setLayout('');
    }

    public function request_login($username, $password) {
        $link =  "http://" . "192.168.128.13:8081/NataRest/api/users/login/" . $username;

        $data = null;
        $http = new Client();
        $response = $http->get($link, [
            'headers' => [
                'api-key' => '24321d8c-b1b3-45bc-9d21-038dfc33b34c',
                'passwd' => $password
            ]
        ]);
        $this->set('response_code', $response->getStatusCode());
        $this->set('response_body', $response->body);

        if($response->getStatusCode() >= 200 && $response->getStatusCode() <= 299){
            return;
        }else {
            $this->redirect('/login');
        }
    }

    public function signin() {
        $this->viewBuilder()->setLayout('');
    }

}